<?php

$phone = 8888888888;
$email = 'abc@gmail.com';
$address = 'office no 10';


$facebook = 'facebook.com/travel';
$twitter = 'twitter.com/travel';
$instagram = 'instagram.com/travel';
$pinterest = 'pinterest.com/travel';
$linkedin = 'linkedin.com/travel';
$youtube = 'youtube.com/travel';
